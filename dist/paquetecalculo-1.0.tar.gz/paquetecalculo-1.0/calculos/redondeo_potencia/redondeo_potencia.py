def potencia(base,exponente):
    print("El resultado de la potencia es: ", base**exponente)

def redondear(numero):
    print("El resultado del redondeo es: ", round(numero))