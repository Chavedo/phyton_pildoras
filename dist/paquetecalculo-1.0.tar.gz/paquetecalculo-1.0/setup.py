from setuptools import setup

setup(

    name="paquetecalculo",
    version="1.0",
    description="Paquete de redondeo y potencia",
    author="Mariano",
    author_email="asd@gmail.com",
    url="www.google.com.ar",
    packages=["calculos","calculos.redondeo_potencia"]

)